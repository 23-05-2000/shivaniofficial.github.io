import { Component } from '@angular/core';
import { ConfigService } from '../config.service';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrl: './sign-in.component.css'
})
export class SignInComponent {

  public learners = [] as any;
  constructor(private configService: ConfigService) { }
  ngOnInit() {
    this.configService.getLearners().subscribe(data => this.learners = data);
  }

}
