import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'productmanagement';

  constructor(private router:Router){}
  //user-defined method to navigate from one component to another
  getHome()
  {
    this.router.navigate(['/home']);
  }
  getContactUs()
  {
    this.router.navigate(['/contactus']);
  }
  getProduct()
  {
    this.router.navigate(['/product']);
  }
  getLogin()
  {
    this.router.navigate(['/login']);
  }
  
}
