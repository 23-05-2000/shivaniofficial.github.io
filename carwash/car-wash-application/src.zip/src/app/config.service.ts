import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  private url: string = "/assets/learners.json";

  constructor(private http: HttpClient) { }

  getLearners(): Observable<any> {
    return this.http.get(this.url).pipe(
      retry(3),
      catchError(this.handleError)
    );
  }
  private handleError(error: HttpErrorResponse) {

    if (error.status === 0) {
      //** Client side or Network Error */
      console.error('An error occurred:', error.error);
    }
    else {
      // Handling backend errors.i.e: pageNotFound,500,internalServerError
      console.error(`Backend returned code ${error.status},body was :`, error.error);
    }

    return throwError(() => new Error('Something bad happened please try again'));
  }
}
