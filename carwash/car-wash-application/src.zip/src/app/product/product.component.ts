import { Component } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})
export class ProductComponent {

  constructor(private productService: ProductService){}
  products!: Product[];

  //ngOnInit it will call on page loads
  ngOnInit(){
    this.products = this.productService.getProducts();
  }

}
