import { Injectable } from '@angular/core';
import { Product } from './product';
@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor() { }

  public getProducts(){
    let products:Product[];
    products = [
      new Product(1,'Mobile',50000),
      new Product(2,'Laptop',100000),
      new Product(3,'CPU',80000),
      new Product(4,'Washing Machine',30000),
      new Product(5,'SmartTV',50000)
    ];
    return products;
  }
}
